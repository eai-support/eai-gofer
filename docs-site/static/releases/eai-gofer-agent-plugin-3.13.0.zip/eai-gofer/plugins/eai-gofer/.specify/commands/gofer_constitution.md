---
name: gofer_constitution
description: "Create or update project constitution with coding principles and guidelines."
title: "Gofer Constitution"
category: utility
surfaces:
  - claude
  - claude-mirror
  - copilot
  - vscode
  - codex
  - gemini
  - github-prompts
  - agents-skills
  - system-skills
aliases: [gofer:constitution]
---
---
description:
  Create or update project constitution with coding principles and guidelines
---

# Gofer Constitution

## Continuation And Stop Contract
<!-- gofer:continuation:start -->

1. Preserve the requested scope and mode, including read-only, plan-only, research-only and MVP work. Keep the full applicable pipeline, stage functions, artifacts, reviews and validation; do not expand an MVP into an unapproved release.
2. After a stage's required evidence is complete, read and follow the next internal file in .specify/commands/ in the same conversation. Do not require a numbered command or a host-specific skill dispatcher. Optional helpers remain optional; maintenance and control commands do not start delivery work.
3. Treat the stated business goal as authority for ordinary planning, task ordering, design, diagnosis, repair, testing, and reversible repository changes within scope. Record material Gofer decisions with their reason and effect. Do not ask the user to choose implementation details that Gofer can safely decide.
4. Ask only when the goal is unclear or changes, the action is irreversible or destructive, it changes security or access, it creates external cost or commitment, it changes production or public exposure, it requires missing authority or credentials, or it conflicts with an explicit user constraint. Record the exact reason before asking. missing or ambiguous approval is not approval when an approval boundary applies. Rejected, revoked, changed or unclear authority requires a pause.
5. Pause for material scope, security, cost, deployment, destructive or protected files/boundary changes and any outstanding user gate. A business goal does not authorize publishing, spending, external changes, or bypassing host permissions. Complete safe authorized work without bypassing the blocked gate.
6. A tool proposal is not execution. If host consent is required, wait for it. After the tool result or approved proposal returns, inspect the result and resume the next authorized action within approved scope; do not end with only a plan or a proposed tool call. A denied tool or unavailable capability must not be bypassed through another host or CLI.
7. Use the current agent's available native tools. Optional Gofer/MCP tools are conveniences, not prerequisites. If the current agent lacks a required capability, report that limitation and the safe next action; do not pretend a handoff button transfers control automatically.
8. Stop after research only when research-only work was requested, the user paused, or a real gate blocks progress. Otherwise continue to specification. At validation, report completion only when the requested scope's required evidence passes; failures remain unfinished work.
9. Respect budget, context and retry limits from the existing loop contract. Repair safe within-scope failures only within those limits. Preserve a checkpoint before an orderly context stop; resume by reading its recorded stage and rechecking scope, approvals and evidence. Never claim an abrupt host termination was handled.
10. Report concise Progress during work. At every controlled stop, report Progress, Stop reason and Next action, including the exact missing input or approval and unfinished work. Reasons are requested scope complete, user pause, approval required, material change, missing capability/access, validation blocked, or budget/context/retry limit. Stage completion alone is not pipeline completion.

**Blocker Mediation**

- Before repeating a failed action or asking for missing input, read .specify/references/blocker-mediation.md and inspect the private blocker register with gofer-blocker-control.mjs. Reuse the same state directory and goal, subject and condition keys across stages, restarts and surfaces. Different wording, models or tools do not create a new blocker.
- Classify the cause first. Missing user decisions, access, external dependencies and unavailable capabilities require a recorded wait. Reserve an ask event before asking; ask once, explain the business impact and required change, then stop affected work. An unanswered question is not new evidence. Do not poll or rephrase it to keep running.
- Technical ask events require a fresh verification file under .specify/references/priority-outcome-protection.md: actual diagnosis, self-cause check and why no authorized repair is available. Business choices need no failed command. For feature tasks, use gofer-priority-check.mjs and the saved direction before switching work; this does not start delivery during maintenance or conversation.
- For AI-solvable or unknown causes, reserve each attempt before execution. Allow one investigation and one different recovery within existing tighter budgets. Record its result even when interrupted or unsuccessful. An unfinished reservation must not launch again. Do not reset the register, change keys or switch surfaces to obtain more attempts.
- Resume only after a real user answer or changed external evidence has been recorded and checked. The helper allows one evidence-backed resumption; exhausted limits need human review. Never invent approval or evidence. Successful model output and a running server do not resolve a blocker without the relevant check.
- Save the blocker, unfinished tasks and next action before stopping. Continue only approved tasks that do not depend on it. Keep the original goal; update specs, plans, tasks and validation for accepted direction changes, and reopen stale checks. Do not quietly drop requirements to make progress.
- Use node .specify/scripts/node/gofer-blocker-control.mjs --state-dir <private-state-directory> --event <private-event.json> before controlled actions; inspect with --state-dir alone, or add --task T001 for an independent task. A denied action, invalid record or missing helper means stop and explain the limitation, not bypass it. Use the installed plugin script path if no repo scaffold exists. Conversation-only work uses a private session state directory and does not require app setup or feature files.
- Strict loop validation checks every recorded feature blocker. Shared instructions guide native chats; this helper cannot intercept calls that a host sends directly. Do not claim native enforcement from package tests alone.


## Verified Specialist Execution

Use .specify/references/verified-agent-execution.md before specialist delegation in any app or non-app stage. The shared agent-catalog.json retains specialist responsibilities. Resolve roles with gofer-agent-catalog.mjs; obtain tools and models from the current host, never from another provider's examples. Keep internal roles out of the public command picker.

Preserve every required review. Provider-specific Task/model examples describe intent, not portable commands or proof of support. Run independent work together only when dependencies, permission boundaries, scope and budgets allow it. Otherwise serialize supported work. A required independent review remains unverified if separate execution is unavailable; never relabel self-review as independent.

The experimental gofer-verified-execution.mjs controller accepts trusted adapters, not worker-supplied commands. It checks current priority, bounds calls and attempts, records required checks, and rejects stale results. Its local process tests do not qualify native model execution. Do not activate an unqualified host adapter or bypass existing blocker, permission, outcome or release gates. Preserve normal safe Gofer work and explain the limitation.

<!-- gofer:continuation:end -->

## MVP Capability-Based Validation

Use `.specify/references/mvp-capability-validation.md` as the source of
truth. Validate the work that the active feature specification requires now.
Do not apply later delivery requirements to an early MVP.

1. Create `.specify/specs/{feature}/` before app or operator-tool source work.
2. Keep `spec.md`, `plan.md`, `tasks.md`, `traceability.md`, and the validation scope aligned.
3. Mark each relevant capability as `not_applicable`, `planned`, `implemented`, `verified`, or `blocked`.
4. Require evidence only for an implemented capability or a capability required by the current delivery decision.
5. Treat `run.sh`, `run.bat`, and `run.ps1` as launch evidence only. They do not prove authentication, sessions, EAI access, or deployment readiness.
6. For a user-facing change, store the local HTTP check, screenshot, and review outcome in the feature validation report.
7. If browser validation is blocked, mark that user journey `unverified`. Do not call it complete.
8. If the user changes scope, update the feature artifacts before continuing. Explain what changed, what remains valid, and what now needs evidence.
9. Use truthful completion language. For example: `The server runs. Authentication is not in the current MVP scope.`
10. When the feature claims a release or deployed outcome, create `release-capability-ledger.md` from `.specify/templates/release-capability-ledger-template.md`.
11. Do not report a release complete or score 100% when a required capability is missing from traceability, remains on an open PR, is absent from the release branch, or lacks required deployed evidence.

## Application Classification And EAI Preflight

Before any EAI CLI, login, tenant, template, or app-enrollment action:

1. Classify the request as **EAI app delivery** or **non-application work** using the application signals in `.specify/commands/0_gofer_start.md`.
2. Create `.specify/specs/{feature}/` and record the active delivery scope before app or operator-tool source work.
3. If the request is clearly non-app work, confirm once: **"This looks like non-app work, so I will skip EAI tenant/app setup and continue the Gofer research/docs path. Is that right?"**
4. If the user confirms non-app, record the decision and mark app-only capabilities `not_applicable`. Do not run `eai whoami`, `eai tenant select`, `eai init`, or `/gofer:eai-first-run`.
5. For local MVP app work, validate the implemented user journey, repo runner, and preview evidence. Do not require EAI setup, authentication, or deployment when the active specification does not require them.
6. When the feature uses EAI Platform services, requires a tenant, or prepares deployment, run `eai whoami` and record the EAI readiness evidence in `eai-preflight.md`.
7. When the feature creates, changes, or validates an EAI Platform app integration, run `node .specify/scripts/node/eai-app-template-readiness.mjs --root . --json`. A missing checker or status other than `ready` blocks that EAI capability. It does not block unrelated local MVP work.
8. When authentication is implemented or required, validate provider, callback, sign-in, session, first protected API call, and safe denied access.
9. When deployment is requested or claimed, require the relevant EAI template, security, configuration, and deployment evidence before completion.
10. For durable app delivery, use EAI Platform first, Azure second, and every other stack only by explicit exception.
11. If the user changes scope, update `spec.md`, `plan.md`, `tasks.md`, `traceability.md`, and validation scope before continuing. Explain the business effect and evidence change.
12. Do not accept copied marker files, partial scaffolds, or custom templates as readiness evidence for an EAI capability.
13. Do not write tokens, secrets, private tenant IDs, or local `.env` values into Gofer artifacts; record only product-safe readiness status and evidence.

**Authentication Access Decision**

When adding or changing authentication, read `.specify/references/platform/eai-auth-access.md`. Ask: **"Who should be able to use this app: only members of its EAI workspace (recommended), or any authenticated EAI user?"** Default to `workspace-only`. Wait for the answer before changing auth code. An unanswered question must not widen access. Preserve stricter existing rules. Record the answer in the feature spec; do not repeat a confirmed question unless its scope changes.

Confirm the sign-in method separately: EAI sign-in or client SSO through EAI. Verify platform support and CLI syntax; do not invent SSO commands. Enforce trusted server-side workspace membership and app permissions. A session, CIAM directory ID, or email domain alone is not workspace access. Platform-wide sign-in never grants access to another workspace's data. Test allowed and denied users, revoked membership, unavailable membership checks, and cross-tenant requests. These checks apply only when authentication is implemented or required, not to non-app work or an auth-free local MVP.

## Token And Cost Policy
<!-- gofer:token-cost-policy:start -->

Before spawning agents, calling tools, or loading large files:

1. Treat `.specify/memory/gofer-model-policy.yaml` as advisory capability, cost, and quality constraints. A fresh signed host receipt and independently verified benchmark evidence select the model. If it is missing, run `/gofer:bootstrap-workspace` before continuing.
2. Use the lowest-cost model that the live router qualifies for this task. Its signed host receipt and independent benchmark evidence must govern the exact model identity. Do not select a model from static provider examples, names, or price alone.
3. Keep raw tool output out of the main conversation context. Save stable findings to `.specify/specs/{feature}/context-bundle.md`, then work from summaries.
4. Use provider prompt/context caching only for stable, non-secret prefixes: Gofer scaffold, AGENTS/CLAUDE/Copilot instructions, constitution, repo map, stage contracts, and validation rubric.
5. Before continuing after large research, planning, implementation, or validation bursts, checkpoint the durable artifacts and compact/clear/resume context when the host supports it.
6. Escalate model tier only when a cheaper pass is low-confidence, contradictory, security-sensitive, or blocking release quality.
<!-- gofer:token-cost-policy:end -->

## Business-Friendly Progress Contract
<!-- gofer:business-progress:start -->

Default user-facing updates must be concise, business-level, and easy to scan.
Keep the technical work rigorous in artifacts, tests, logs, and code, but do
not lead with implementation jargon unless the user asks for it.

Use ASD-STE100 Simplified Technical English as the target writing standard for
all Gofer-authored chat, documents, commands, summaries, PR notes, error
guidance, and validation artifacts. ASD-STE100 is copyright and a trademark of
ASD; do not bundle the protected ASD dictionary and do not claim ASD
certification.

1. Explain progress as what is being connected, changed, checked, or fixed and
   why it matters to the business outcome.
2. Use the running build map: create or update
   `.specify/specs/{feature}/build-map.md` from
   `.specify/templates/build-map-template.md` for application delivery, and
   refer to its plain-language areas in progress updates.
3. When there is a problem, translate it into business impact, current status,
   next action, and what input or approval is needed. Keep raw stack traces,
   command logs, IDs, and acronyms out of chat unless asked.
4. If the user asks for technical depth, provide it on request and point to the
   durable artifact that contains the evidence.
5. Prefer a compact update shape:
   - `Working on`: the build-map area or stakeholder outcome
   - `Why it matters`: user/business impact
   - `Status`: done, checking, fixing, blocked, or needs decision
6. Use one action per instruction.
7. Keep instructions to 20 words or fewer where possible.
8. Use active voice unless the actor is unknown or not important.
9. Use simple verb forms: simple present, simple past, simple future,
   infinitive, or imperative.
10. Define acronyms on first use and use approved project terms.
11. Avoid idioms, marketing adjectives, vague praise, and hedging.
12. Use vertical lists for complex information and one topic per paragraph.
13. For errors, state what happened, why it matters, what to do next, and the
    exact safe command when one exists.
14. Do not remove technical validation, security checks, EAI preflights, tests,
   or loop evidence. This contract changes presentation, not engineering
   standards.
15. Before each user-facing reply, check that it leads with the business effect,
    uses concise simple language, and includes only useful technical detail.
16. If any check fails, rewrite the reply before sending it.
**Business Updates And Goal Checks**

Use `.specify/references/business-updates-and-goal-checks.md`. Before each reply, explain the result, business effect, and next action in plain language. For progress, use two or three short sentences. Run `node .specify/scripts/node/gofer-response-check.mjs --input <private-draft-file>` before sending a drafted progress update; rewrite failed drafts. Use `--kind answer` for answers and `--technical` only when technical detail was requested. Do not repeat unchanged progress. This helper cannot intercept messages that the host sends directly.

Before each work batch, read the current goal, specification, tasks, and latest findings. Make ordinary design, sequencing, diagnosis, repair, and verification decisions that advance the goal. Record material decisions and update affected feature documents when new evidence changes the path. Never weaken acceptance criteria to match failing code. Do not invent approval where approval is required. Mark a task complete only after its linked checks pass; reopen affected tasks when evidence is stale. For app and non-app features with a spec and tasks, enable `requireDeliveryCheckpoint` in `loop-contract.json` and run `node .specify/scripts/node/gofer-delivery-check.mjs --feature-dir <feature-dir>` before advancing or claiming completion. Follow the reference to capture a reviewed checkpoint, not merely to clear a failure. Keep existing MVP exemptions, reviews, loops, and release gates. Conversation-only requests need no feature files.

**Priority And Outcome Protection**

Follow `.specify/references/priority-outcome-protection.md`. Treat the stated goal as authority for ordinary delivery decisions. Record material user direction and Gofer decisions in decisions.md. Maintain priority-plan.json with ordered tasks, dependencies, allowedEditScope and the current outcome. Enable requirePriorityPlan for new feature contracts. Run `node .specify/scripts/node/gofer-priority-check.mjs --feature-dir <feature-dir> --task T001` before the action, and include --workspace <repo-root> plus --changed-file for each proposed or actual changed repo-relative path. Follow its nextTask; recorded independent work may run in parallel. Do not switch to unrelated work when blocked. Ask only when a decision changes the goal, needs missing authority or access, causes irreversible loss, creates external cost or commitment, changes production or public exposure, or conflicts with an explicit user constraint. On resume, state the agreed outcome and next task in plain language after reading the last recorded direction. Keep routine conversation free of feature paperwork.

Before technical escalation, attach fresh diagnosis through the blocker helper's ask event verification field. Check the exact command, route, environment, own mistake and existing authority. Do not invent a tenant, ask for login without checking it, require an unsafe alternative, or equate administrator access with permission. Business decisions need no failing command. At completion, run the priority checker with --finish; a missing or stale outcome receipt means unverified, regardless of test scores. Use --completion for the final gofer-closed-loop-audit.mjs run; a routine drift audit alone does not prove completion. When TypeSafe semantic review is enabled for the feature, run `node .specify/scripts/node/gofer-semantic-drift.mjs --workspace <repo-root> --feature-dir <feature-dir> --event <resume|before_task_batch|after_material_finding|before_validation>` at resume, before a material task batch, after a material finding, and before validation. A TypeSafe conflict or uncertain result requires Gofer reconciliation; it cannot edit artefacts, bypass scope controls, or complete work. Preserve detailed test results, early local MVP scope, non-app work, independent approved tasks and all release/security checks.

<!-- gofer:business-progress:end -->

## App Preview Runner Contract
<!-- gofer:app-preview-runner:start -->

For EAI app delivery, every UI preview must use the repo runner when it exists.

1. Use `./run.sh dev 3001` on macOS, Linux, and GitHub Codespaces.
2. Use `run.bat dev 3001` on Windows.
3. Use a different port only when the feature notes record the reason.
4. Restart only this app. Before stopping a process, verify its exact checkout, process ID, start time and command, then recheck immediately before stopping it. Never stop another app, an unknown process, or every process on a port. If ownership is uncertain, leave it running and ask the user. Inspect older runners before use; do not run one that kills by port alone.
5. Do not use direct `npm run dev`, `next dev`, or package-manager preview commands when `run.sh`, `run.bat`, or `run.ps1` exists.
6. After every UI-facing change, run:
   - `node .specify/scripts/node/gofer-ui-preview.mjs --feature-dir {FEATURE_DIR} --command "./run.sh dev 3001" --open auto --screenshot --change "<change summary>"`
7. On Windows, use:
   - `node .specify/scripts/node/gofer-ui-preview.mjs --feature-dir {FEATURE_DIR} --command "run.bat dev 3001" --open auto --screenshot --change "<change summary>"`
8. If the runner is missing in an EAI app template repo, refresh the template before preview work continues.
9. Check the exact preview page and the current implemented user journey after each change. A running process, open browser, screenshot alone, error page or dry run is not proof that it works. Say ready to view only after those checks pass. Otherwise explain what is unchecked or failing; do not claim readiness. Record fresh browser and test evidence. Local MVP checks cover only implemented behaviour; do not add future auth or deployment gates. Keep showing clearly labelled drafts without adding approval stops.
<!-- gofer:app-preview-runner:end -->

## Source-of-Truth and Codex Distribution (FR-001, FR-010)

The Gofer constitution lives at `.specify/memory/constitution.md` and is the
authoritative reference for cross-cutting concerns the entire pipeline must
respect.

Two invariants the constitution MUST document and this command MUST preserve
when updating:

1. **Source-of-truth (FR-001)**: All stage commands derive from canonical files
   at `.specify/commands/<stage>.md` — YAML frontmatter (name, description ≤140
   chars, surfaces, args) plus Markdown body. The generator at
   `.specify/scripts/node/generate-commands.mjs` emits to every CLI surface
   (`.claude/commands/`, `extension/resources/copilot-prompts/`,
   `.github/prompts/`, `.gemini/commands/gofer/`, `.agents/skills/`, and the
   legacy compatibility mirror `.system/skills/`). Hand-edits on emitted files
   are rejected by the generator without `--force-emit`. **Never bypass the
   source-of-truth.**

2. **Codex distribution path (FR-010)**: Codex discovers skills at
   `.agents/skills/` (one folder per skill:
   `.agents/skills/<stage>/SKILL.md`). This is NOT the same as
   `.claude/skills/`, and it is the only repo-local path Codex should rely on
   for normal Gofer installs. The constitution MUST capture that distinction
   explicitly so future authors do not conflate the two paths or recreate
   duplicate global Gofer bundles. The official Codex disable knob is a
   per-skill `[[skills.config]]` entry with a `path = "/full/path/to/skill"`
   plus `enabled = false` in `~/.codex/config.toml`; there is no global
   skill-budget percentage key (FR-011).

When updating the constitution, ensure both sections survive the edit pass.

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

---

## Why Constitution Matters for Agentic Coding

1. **Consistency Across Sessions**: Agents follow the same rules every time
2. **Memory Persistence**: Decisions survive context window limits
3. **Team Alignment**: All agents (and humans) follow same guidelines
4. **Quality Gates**: Automatic validation against principles
5. **Knowledge Capture**: Learnings from past work inform future work

---

## When to Use This Command

- **Project Setup**: Initialize constitution for new project
- **Post-Implementation Learning**: Capture decisions from completed features
- **Standards Update**: Add new conventions or patterns
- **Onboarding**: Document expectations for new team members/agents

---

## Step 1: Check Existing Constitution

```bash
# Check if constitution exists
if [ -f ".specify/memory/constitution.md" ]; then
  echo "Constitution exists - will update"
else
  echo "No constitution - will create"
fi
```

Read existing constitution if present.

---

## Step 2: Gather Principles

### If Creating New Constitution

Ask the user using AskUserQuestion:

```
I'll help you create a project constitution. What areas would you like to define?

1. Coding Standards (naming, formatting, patterns)
2. Architecture Principles (structure, dependencies, layering)
3. Testing Requirements (coverage, types, conventions)
4. Security Guidelines (auth, data handling, secrets)
5. Performance Standards (targets, monitoring, optimization)
6. Documentation Requirements (comments, READMEs, ADRs)
7. All of the above (I'll ask about each)
```

### If Updating Existing Constitution

Ask:

```
What would you like to update in the constitution?

1. Add new principle(s)
2. Modify existing principle(s)
3. Remove outdated principle(s)
4. Add architectural decision record (ADR)
5. Update coding standards
6. Review and validate current constitution
```

---

## Step 3: Research Codebase Patterns

Before writing principles, understand current codebase:

```
Task: subagent_type="codebase-pattern-finder", model="haiku"
Prompt: "Analyze the codebase for existing patterns and conventions.
Find:
- Naming conventions (files, variables, functions)
- Code organization patterns
- Testing patterns and conventions
- Error handling patterns
- Documentation style
Report patterns that should be formalized as principles."
```

---

## Step 4: Generate Constitution

Write to `.specify/memory/constitution.md`:

````markdown
---
version: 1.0
created: [ISO date]
updated: [ISO date]
status: active
---

# Project Constitution

> This document defines the principles and standards that guide all development
> work in this project. AI agents and human developers MUST follow these
> guidelines.

## Core Principles

### P1: [Principle Name]

**Statement**: [Clear, actionable statement]

**Rationale**: [Why this matters]

**Examples**:

- Good: [Example of following this principle]
- Bad: [Example of violating this principle]

**Enforcement**: [How this is validated]

### P2: [Principle Name]

...

## Coding Standards

### Naming Conventions

| Element   | Convention        | Example           |
| --------- | ----------------- | ----------------- |
| Files     | [kebab/camel/etc] | `user-service.ts` |
| Classes   | [PascalCase]      | `UserService`     |
| Functions | [camelCase]       | `getUserById`     |
| Constants | [UPPER_SNAKE]     | `MAX_RETRY_COUNT` |
| Variables | [camelCase]       | `userData`        |

### Code Organization

```
src/
├── [layer]/           # [Description]
│   ├── [sublayer]/    # [Description]
│   └── index.ts       # Public exports only
├── types/             # Shared type definitions
├── utils/             # Shared utilities
└── index.ts           # Main entry point
```
````

### Import Order

1. External packages (node_modules)
2. Internal absolute imports
3. Relative imports
4. Type imports (if separate)

### Error Handling

- MUST: [Error handling requirement]
- MUST NOT: [Anti-pattern to avoid]
- SHOULD: [Best practice]

## Architecture Principles

### Dependency Direction

```
UI → Application → Domain → Infrastructure
     ↓
   Never depend on layers above
```

### Component Boundaries

| Component | May Depend On      | Must Not Depend On |
| --------- | ------------------ | ------------------ |
| UI        | Application, Types | Domain, Infra      |
| Domain    | Types              | Anything else      |

### State Management

- [Principle about state]
- [Where state should live]
- [How state should flow]

## Testing Requirements

### Coverage Targets

| Type        | Target    | Current  |
| ----------- | --------- | -------- |
| Unit        | 80%       | [X]%     |
| Integration | 60%       | [X]%     |
| E2E         | Key flows | [status] |

### Test Patterns

- Use DSL functions for readability
- Follow Arrange-Act-Assert structure
- One assertion concept per test
- Test behavior, not implementation

### Required Tests

- [ ] All public API functions
- [ ] All error handling paths
- [ ] All edge cases identified in specs

## Security Guidelines

### Authentication/Authorization

- [Requirement]
- [Pattern to follow]

### Data Handling

- NEVER: Store secrets in code
- NEVER: Log sensitive data
- ALWAYS: Validate external input
- ALWAYS: Use parameterized queries

### Secrets Management

- Location: [Where secrets go]
- Format: [How to reference]
- Rotation: [Policy]

## Performance Standards

### Response Time Targets

| Operation  | Target  | Critical Path? |
| ---------- | ------- | -------------- |
| API call   | < 200ms | Yes            |
| Page load  | < 2s    | Yes            |
| Background | < 30s   | No             |

### Resource Limits

- Memory: [Limit]
- CPU: [Limit]
- Bundle size: [Limit]

## Documentation Requirements

### Code Comments

- Document "why", not "what"
- Required for: complex logic, workarounds, non-obvious decisions
- Not required for: self-explanatory code

### API Documentation

- All public functions must have JSDoc/docstrings
- Include: description, parameters, return value, errors

### Architecture Decision Records

When making significant decisions, create ADR in `.specify/memory/decisions/`.

## Quality Gates

These checks MUST pass before code is considered complete:

```bash
# Automated checks
npm run lint        # Zero errors
npm run typecheck   # Zero errors
npm test            # All pass
npm run build       # Successful

# Manual checks
- [ ] Code review approved
- [ ] Tests cover new functionality
- [ ] Documentation updated
```

## Violations and Exceptions

### How to Handle Violations

1. **Accidental**: Fix before committing
2. **Intentional**: Document exception with ADR
3. **Systemic**: Propose constitution amendment

### Exception Format

When violating a principle intentionally:

```typescript
// CONSTITUTION EXCEPTION: P3 - [Principle Name]
// Reason: [Why violation is necessary]
// ADR: .specify/memory/decisions/NNN-exception.md
// TODO: [Plan to resolve, if any]
```

## Version History

| Version | Date   | Changes              | Author |
| ------- | ------ | -------------------- | ------ |
| 1.0     | [date] | Initial constitution | Claude |

````

---

## Step 5: Create Decision Record Template

Ensure `.specify/memory/decisions/` exists and has template:

```markdown
# .specify/memory/decisions/000-template.md

---
id: NNN
title: '[Decision Title]'
status: [proposed|accepted|deprecated|superseded]
date: [ISO date]
deciders: [who made this decision]
---

# [Decision Title]

## Context

[What is the issue we're addressing?]

## Decision

[What is the change we're making?]

## Consequences

### Positive

- [Benefit 1]
- [Benefit 2]

### Negative

- [Drawback 1]
- [Drawback 2]

### Neutral

- [Side effect]

## Alternatives Considered

### Alternative 1: [Name]

- Pros: [benefits]
- Cons: [drawbacks]
- Why rejected: [reason]

### Alternative 2: [Name]

...

## Related Decisions

- [Link to related ADR]
````

---

## Step 6: Validate Constitution

After creating/updating, validate:

### Consistency Check

- [ ] All principles are actionable (not vague)
- [ ] No contradictory principles
- [ ] Examples provided for clarity
- [ ] Enforcement method defined

### Codebase Alignment Check

```
Task: subagent_type="codebase-analyzer", model="sonnet"
Prompt: "Check if the codebase follows these constitution principles:
[List key principles]
Report any violations or areas needing attention."
```

### Completeness Check

- [ ] Coding standards defined
- [ ] Architecture principles defined
- [ ] Testing requirements defined
- [ ] Security guidelines defined
- [ ] Quality gates defined

---

## Step 7: Report Completion

```
================================================================
  CONSTITUTION [CREATED/UPDATED]: [Project Name]
================================================================

  Location: .specify/memory/constitution.md

  Sections:
  - Core Principles: [N] defined
  - Coding Standards: [Complete/Partial]
  - Architecture: [Complete/Partial]
  - Testing: [Complete/Partial]
  - Security: [Complete/Partial]
  - Quality Gates: [N] checks

  Validation:
  - Consistency: [Pass/Issues found]
  - Codebase alignment: [X]% following principles
  - Completeness: [X]/[Total] sections

  Next Steps:
  1. Review with team
  2. Address any violations found
  3. Add to onboarding documentation
  4. Reference in /3_gofer_plan for alignment checks

================================================================
```

---

## Integration with Pipeline

### During Planning (/3_gofer_plan)

```markdown
## Constitution Check

- [x] P1: [Principle] - Plan aligns
- [x] P2: [Principle] - Plan aligns
- [ ] P3: [Principle] - Exception needed (see ADR-NNN)
```

### During Implementation (/5_gofer_implement)

Before each task, verify implementation follows constitution.

### During Validation (/6_gofer_validate)

```markdown
## Constitution Compliance

| Principle | Status    | Notes             |
| --------- | --------- | ----------------- |
| P1        | Pass      | -                 |
| P2        | Pass      | -                 |
| P3        | Exception | ADR-NNN documents |
```

---

## Updating Constitution

When learnings emerge from feature work:

1. Run `/gofer_constitution` with update flag
2. Add new principles or modify existing
3. Create ADR for significant changes
4. Update version history
5. Notify team of changes

---

## Observability Logging

```bash
.specify/scripts/bash/log-stage.sh gofer_constitution --complete --tokens [N] --compactions [N]
```

---

## Key Rules

- Constitution is **authoritative** - all work must align
- Principles must be **actionable** - not vague aspirations
- **Exceptions require ADRs** - no silent violations
- **Version control** constitution changes
- Constitution informs **all pipeline stages**

## Local Settings Cleanup Contract
<!-- gofer:local-settings-cleanup:start -->

After any Gofer install, update, release refresh, or workspace bootstrap:

1. Archive stale Gofer command and skill entries before continuing.
2. Prefer the repo helper:
   - `node .specify/scripts/node/gofer-local-settings-cleanup.mjs --workspace . --apply --json`
3. If the repo helper is missing, use the stable plugin bundle helper:
   - macOS/Linux: `node ~/plugins/eai-gofer/.specify/scripts/node/gofer-local-settings-cleanup.mjs --workspace . --apply --json`
   - Windows: `node %USERPROFILE%\plugins\eai-gofer\.specify\scripts\node\gofer-local-settings-cleanup.mjs --workspace . --apply --json`
4. This cleanup covers old Claude, Codex, Copilot, Gemini, Grok, VS Code, desktop, and CLI command surfaces.
5. Do not remove the current public `eai` entrypoint.
6. Ask the user to refresh or restart the host command picker only after cleanup completes.
<!-- gofer:local-settings-cleanup:end -->
